package team6.java.ca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

;


@SpringBootApplication
public class Team6JavaCaFinalApplication {

	public static void main(String[] args) {
		SpringApplication.run(Team6JavaCaFinalApplication.class, args);
		
		
	}

}
