package team6.java.ca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Team6JavaCaFinalApplicationTests {

	@Test
	void contextLoads() {
	}

}
